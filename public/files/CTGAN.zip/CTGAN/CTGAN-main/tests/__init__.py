"""CTGAN tests."""
