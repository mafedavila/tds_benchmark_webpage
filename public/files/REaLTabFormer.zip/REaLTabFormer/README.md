# Introduction
This guide shows you how to configure your use case and start generating synthetic tables.
Follow the steps below to run your first experiment.

# Example

The provided .zip file includes an example based on the "adult" dataset.
You can find it in the Examples folder.

# Input Data

In the third cell of the Jupyter notebook, replace the example dataset name and file path with the name and path of your own data.