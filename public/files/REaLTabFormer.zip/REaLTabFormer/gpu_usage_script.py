import torch
import gpustat
import time

def get_gpu_usage():
    stats = gpustat.new_query()
    gpu_usage = {gpu.index: gpu.memory_used / gpu.memory_total * 100 for gpu in stats}
    return gpu_usage

def simple_gpu_task():
    # Check if CUDA is available
    if torch.cuda.is_available():
        # Set device to GPU
        device = torch.device("cuda")
        print(f"Using GPU: {torch.cuda.get_device_name(0)}")
        
        # Generate random data and perform matrix multiplication
        data = torch.randn(5000, 5000, device=device)
        result = torch.matmul(data, data)
        
        # Ensure completion of CUDA operations
        torch.cuda.synchronize()
        
        # Check GPU usage after the task
        gpu_usage_after = get_gpu_usage()
        print(f"GPU Usage after task: {gpu_usage_after[0]:.2f}%")
    else:
        print("CUDA is not available, using CPU.")


def get_gpu_usage2():
    stats = gpustat.new_query()
    if stats.gpus:
        gpu = stats.gpus[0]
        return gpu.memory_used / gpu.memory_total * 100, gpu.utilization
    return 0, 0  # If no GPU data available, return 0

simple_gpu_task()
