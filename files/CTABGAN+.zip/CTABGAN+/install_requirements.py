import subprocess

def install_requirements(requirements_file):
    with open(requirements_file) as f:
        requirements = f.read().splitlines()
    
    for requirement in requirements:
        subprocess.run(['pip', 'install', requirement])

if __name__ == "__main__":
    install_requirements('requirements.txt')